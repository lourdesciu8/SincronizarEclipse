package database;

public interface SchemaDB {
    String HOST = "127.0.0.1";
    String DB_NAME = "almacen";
}
